    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proje;
  
public abstract class normalLoc extends Lokasyon {
    // Güvenli alanın constructorunu oluşturuyourz
    normalLoc(Player player  ,String name){
        super(player); //Location sınıfındaki playerı çağırıyoruz
        this.name = name ;
    }
    
    
    public boolean mapLoc(){ // mapLoc true dondugu surece oyun devam edecek ve tekrar ana menuye atayacak
        return true;
    }
}
