    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proje;

import java.util.Random ;
public class Enemy {
    private String name ;
    private int damage,odul,can , maxSayi;
    /* Burada Enemy sınıfının constructorunu oluştuyoruz*/
    public Enemy(String name,  int odul, int can, int damage, int maxSayi) {
        this.name = name;
        this.damage = damage;
        this.odul = odul;
        this.can = can;
        this.maxSayi = maxSayi;
    }
    /*random düşman ataması için gerekli olan method*/
    public int Count(){
       int sayi = (int)(Math.random()*4);
       if(sayi == 0){
       return (sayi+1);
       }
       else{
       return sayi;    
       }   
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getOdul() {
        return odul;
    }

    public void setOdul(int odul) {
        this.odul = odul;
    }

    public int getCan() {
        return can;
    }

    public void setCan(int can) {
        this.can = can;
    }

    public int getMaxSayi() {
        return maxSayi;
    }

    public void setMaxSayi(int maxSayi) {
        this.maxSayi = maxSayi;
    }  
 }