/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proje;

/**
 *
 * @author pc
 */
public class Envanter {
    private int damage  , armor  , saglik;
    private boolean drink , food ,firewood , goldRing;
    private String wName , aName , cName;
    /* envanterin costructorunu oluşturuyoruz */
    Envanter(){
        this.damage =  0 ;
        this.armor = 0;
        this.saglik = saglik ;
        this.wName = null ;
        this.aName = null ;
        this.cName = null ;
        this.drink = false ;
        this.food = false ;
        this.firewood = false ;
        this.goldRing = false ;
        
    }
    
    public boolean isGoldRing(){
        return goldRing ;
    }
    
    public void setGoldRing(boolean goldRing){
        this.goldRing = goldRing ;
    }
    
       public boolean isDrink() {
        return drink;
    }

    public void setDrink(boolean drink) {
        this.drink = drink;
    }
    
    public boolean isFood() {
        return food;
    }
    
    public void setFood(boolean food) {
        this.food = food;
    }

    public boolean isFirewood(){
        return firewood ;
    }

    public void setFirewood(boolean firewood){
        this.firewood = firewood ;
    }
    
     public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }
    public String getwName() {
        return wName;
    }

    public void setwName(String wName) {
        this.wName = wName;
    }

    public String getaName() {
        return aName;
    }

    public void setaName(String aName) {
        this.aName = aName;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    
    public int getArmor() {
        return armor;
    }

    public void setArmor(int armor) {
        this.armor = armor;
    }
    
    public void setSaglik(int saglik){
        this.saglik = saglik ;
    }
    
    public int getSaglik(){
        return saglik ;
    }
      boolean isGoldRing(boolean b) {
        return b;
    }
      boolean isFirewood(boolean b) {
        return b;
    }
    boolean isFood(boolean b) {
        return b;
    }
     boolean isDrink(boolean b) {
        return b;
    }
}
