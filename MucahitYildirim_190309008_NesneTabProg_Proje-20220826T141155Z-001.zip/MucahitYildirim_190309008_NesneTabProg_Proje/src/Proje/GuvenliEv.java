/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proje;

/**
 *
 * @author pc
 */
public class GuvenliEv extends normalLoc{   
    GuvenliEv(Player player){
        super(player , "Güvenli Ev");
    }
    @Override
       public boolean mapLoc(){
         player.setSaglik(player.getRtrnSaglik() + player.getInv().getSaglik());
         System.out.println("**************************");
         System.out.println("* Canınız yenilendi      *");
         System.out.println("* Şuan güvenli evdesiniz *");
         System.out.println("**************************");
         return true ;
    
    }
       
       
}
