package Proje;

import java.io.* ;
import java.util.*; 

public abstract class SavasAlani extends Lokasyon {
    protected Enemy enemy ;
    protected String award ;
    
    public SavasAlani(Player player , String name , Enemy enemy , String award) { // savasAlanının constunu oluşturuyoruz
        super(player);
        this.enemy = enemy ;
        this.name = name ;
        this.award = award ;
    }
        
    public boolean mapLoc(){
        int enemyCount = enemy.Count(); // canavarın sayısını belirliyor 
        System.out.println("\n\nŞuanda "+  this.getName() + " bölgesindesin " +player.getName());
        System.out.println(" Savaşa hazırlan " + enemyCount + " " + enemy.getName() + " tarafından kuşatıldın !" );
        System.out.print("\nSavaş(S) veya Kaç(K) :");
        String selCase = input.next();
        selCase = selCase.toUpperCase(); // harfleri buyuge cevirme
        if(selCase.equals("S")){
            if(SavasDegerleri(enemyCount)){
                System.out.println(this.getName() + " Bölgesinde ne kadar " + enemy.getName() +" varsa hepsi temizlendi\n");    
                ItemWin(); // dusmanlar temizlendiginde ıtemwin methoduna gir
            }   
            if(player.getTotatlCan() < 0){
                System.out.println("Öldünüz!!");
                return false ;  // oyun bitti
            }
        }
        System.out.println("Ana menüye dönüş yapıldı");
        return true; // Yanlış girilen bir değerde ana menüye dönüş sağlar  
    }
    
      public void DosyaOlustur(){
        File file = new File("SavasDegerleri.txt");
        try{
            if(file.createNewFile()){
                System.out.println("Dosya oluşturuldu.");
            }
                
            else{
                    
        }
        }
        catch(IOException e){
                e.printStackTrace();
                }
        
        }
    
    public boolean SavasDegerleri(int enmyCount){
        PrintWriter ciktiAlimi = null ; 
  
        try
        {
            DosyaOlustur();
            ciktiAlimi = new PrintWriter (new FileOutputStream("SavasDegerleri.txt" /*, true*/));
        }
        catch (FileNotFoundException hata ){
            System.out.println("SavasDegerleri.txt dosyası olusturulurken hata oldu...");
            System.exit(0);
        }
        for(int i = 0  ; i< enmyCount ; i++){
            int returnenmyCan = enemy.getCan(); // dusman canını yeniliyoruz 
            oyuncuDeger();      // oyuncu bilgilerini bastirir
            dusmanDeger();      // dusman bilgilerini bastirir
                 while(player.getSaglik() > 0 && enemy.getCan() > 0){ // iki canda sifirdan büyük oldugu sürece donguye gir
                System.out.print("Vur(V) veya Kaç(K) : ");
                String Secim = input.next();
                Secim = Secim.toUpperCase(); // kücük harfi buyuk harfe cevir
                System.out.println("\n");
                if(Secim.equals("V")){
                      ciktiAlimi.println("**** Saldiri yaptiniz ****  ");
                      System.out.println("**** Saldiri yaptiniz ****  ");
                      ciktiAlimi.println("");
                      System.out.println("");
                      ciktiAlimi.println("||================||");
                      enemy.setCan(enemy.getCan() - player.getTotalDamage());  
                      ciktiAlimi.println("||Oyuncu canı : " + player.getSaglik()+ "||") ;
                      System.out.println("||Oyuncu canı : " + player.getSaglik()+ "||") ;
                      ciktiAlimi.println("||" + enemy.getName() + " canı : " + enemy.getCan() +" ||");
                      System.out.println("||" + enemy.getName() + " canı : " + enemy.getCan() +" ||");
                      ciktiAlimi.println("||================||\n");
                      System.out.println("||================||\n");
                   if(enemy.getCan() > 0){      // biz vurduktan sonra dusman caninin sifirdan kücük olma ihtimali var oldugu icin if ile sarta bagladik
                      ciktiAlimi.println("****Düşman size vurdu!! **** \n");
                      System.out.println("****Düşman size vurdu!! **** \n");
                      ciktiAlimi.println("||================||");
                      System.out.println("||================||");
                      player.setSaglik(player.getSaglik()- (enemy.getDamage() - player.getInv().getArmor())); // oncelikle envanterdeki armor degerini dusman saldırı gucunden dusuyoruz armor yok ise deger(0) daha sonrasında oyuncu sagligindan dusuyoruz
                      ciktiAlimi.println("|| Oyuncu canı : " + player.getSaglik() + "||" );
                      System.out.println("|| Oyuncu canı : " + player.getSaglik() + "||" );
                      ciktiAlimi.println("|| " +  enemy.getName() + " canı : " + enemy.getCan() + "  ||");  
                      System.out.println("|| " +  enemy.getName() + " canı : " + enemy.getCan() + "  ||");  
                      ciktiAlimi.println("||================||");
                      System.out.println("||================||");
                         ciktiAlimi.println("");
                         System.out.println("");
                         //ciktiAlimi.close();
                   }
                }
                else{  
                    return false ; // V haricinde bir tuşlama yapılırsa else bloğuna girer false dönerek ana menüye döner.
                }
            }
              if(enemy.getCan() <= 0 &&  player.getSaglik() > 0){
                   ciktiAlimi.println("düşmanı yendiniz..\n");
                   System.out.println("düşmanı yendiniz..\n");
                   player.setPara(player.getPara() + enemy.getOdul());
                   ciktiAlimi.println("Güncel para : " + player.getPara());
                   System.out.println("Güncel para : " + player.getPara());
                   enemy.setCan(returnenmyCan);  
                   
               }
              else {
                return false ; // öldünüz..
              }
        }
        ciktiAlimi.close();        
        return true ; 
    }
    public void oyuncuDeger(){  //oyuncu degerlerini döndüren metod
        System.out.println("");
        System.out.println("*****oyuncu bilgileri*****\n==========" );
        System.out.println("Can : " + player.getSaglik());
        System.out.println("Hasar : " + player.getTotalDamage());
        System.out.println("Para : " + player.getPara());
        if(player.getInv().getDamage() > 0){
            System.out.println("Silah : " + player.getInv().getwName());
        }
        if(player.getInv().getArmor() > 0){
            System.out.println("Zırh : " + player.getInv().getaName());
        }
        System.out.println("==========");
    }
    public void dusmanDeger(){    // dusman degerlerini donduren metod
        System.out.println("\n\n" + enemy.getName()+ " Değerleri \n=========");
        System.out.println("Can : " + enemy.getCan());
        System.out.println("Hasar : " + enemy.getDamage());
        System.out.println("Ödül :" + enemy.getOdul());
        System.out.println("=========");
        System.out.println("");      
    }   
    public void ItemWin(){      // savas sonrası odullerin boolean degeri false ise true dondurur ve odulu kazanırız
        if(this.award.equals("Yemek") && player.getInv().isFood() == false ){
                    System.out.println(this.award + " Kazandınız");
                    player.getInv().setFood(true);
                }
                else if(this.award.equals("Odun") && player.getInv().isFirewood() == false ){               
                    System.out.println(this.award + " Kazandınız");
                    player.getInv().setFirewood(true); 
                }
                else if(this.award.equals("İçecek") && player.getInv().isDrink()== false ){
                    System.out.println(this.award + " Kazandınız");
                    player.getInv().setDrink(true);
                }
                else 
                    if(this.award.equals("Altın yüzük") && player.getInv().isGoldRing()== false ){
                     System.out.println(this.award + " Kazandınız");
                     player.getInv().setGoldRing(true);
                }
    }
    
}