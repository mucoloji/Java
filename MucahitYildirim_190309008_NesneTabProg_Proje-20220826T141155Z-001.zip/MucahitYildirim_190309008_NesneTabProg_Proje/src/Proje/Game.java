/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proje;

import java.util.Scanner;

/**
 *
 * @author pc
 */
import java.io.* ;
import java.util.*; 

public class Game {
     Player player ; 
     Lokasyon location ;
     Scanner input = new Scanner(System.in);
     
    
    public void Baslangic(){
    Scanner input = new Scanner(System.in);
       PrintWriter ciktiAlimi = null ; 
        String dosya = "Baslangic.txt"; 
        try
        {
            ciktiAlimi = new PrintWriter (new FileOutputStream(dosya));
        }
        catch (FileNotFoundException hata ){
            System.out.println("AnaEkran.txt dosyası olusturulurken hata oldu...");
            System.exit(0);
        }
        ciktiAlimi.println("Oyuna hogeldiniz ,kurtulmamız gereken düşmanlar ve toplamamız gereken itemler var. Vakit kaybetmeden başlayalım !!");
        System.out.println("Oyuna hogeldiniz ,kurtulmamız gereken düşmanlar ve toplamamız gereken itemler var. Vakit kaybetmeden başlayalım !!");
        ciktiAlimi.println("Öncelikle isminizi giriniz : ");
        System.out.print("Öncelikle isminizi giriniz : ");
        String playerName = input.nextLine();
        ciktiAlimi.println("");
        System.out.println("");
        ciktiAlimi.println("Merhaba " + playerName);
        System.out.println("Merhaba " + playerName);
        player = new Player(playerName);
        player.karakterSecim();
        ciktiAlimi.close();
        OyunAkisi(); // oyun akısı methodunu atıyoruz
    }
    
    
   public void OyunAkisi(){
        PrintWriter ciktiAlimi = null ; 
        String dosya = "AnaEkran.txt"; 
        try
        {
            ciktiAlimi = new PrintWriter (new FileOutputStream(dosya));
        }
        catch (FileNotFoundException hata ){
            System.out.println("AnaEkran.txt dosyası olusturulurken hata oldu...");
            System.exit(0);
        }
       while(true){
           System.out.println();
       System.out.println("=======================================================");
       ciktiAlimi.println("=======================================================");
       System.out.println();
       ciktiAlimi.println();
       System.out.print("\tNereye gitmek istiyorsun " + player.getName()+ "\n\n");
       ciktiAlimi.println("\tNereye gitmek istiyorsun " + player.getName()+ "\n\n");
       System.out.println("=======================================================");
       ciktiAlimi.println("=======================================================");
       System.out.println("1. Güvenli ev    --> güvenli ev , burası temiz");
       ciktiAlimi.println("1. Güvenli ev    --> güvenli ev , burası temiz");
       System.out.println("2. Köy Alanı    --> Dikkatli ol burada barbar köylüler var");
       ciktiAlimi.println("2. Köy Alanı    --> Dikkatli ol burada barbar köylüler var");
       System.out.println("3. Orman    --> Dikkatli ol burada saraydan kovulmuş haydutlar var");
       ciktiAlimi.println("3. Orman    --> Dikkatli ol burada saraydan kovulmuş haydutlar var");
       System.out.println("4. Kasaba    --> Dikkatli ol Kralın şövalyelerine yakalabilirsin");
       ciktiAlimi.println("4. Kasaba    --> Dikkatli ol Kralın şövalyelerine yakalabilirsin");
       System.out.println("5. Kale    --> Dikkatli ol burada ejdarha yaşıyor");
       ciktiAlimi.println("5. Kale    --> Dikkatli ol burada ejdarha yaşıyor");
       System.out.println("6. Mağaza    --> silah , zırh ve can potu alabilirsiniz ");
       ciktiAlimi.println("6. Mağaza    --> silah , zırh ve can potu alabilirsiniz ");
       System.out.println("7. Çıkış.");
       ciktiAlimi.println("7. Çıkış.");
       System.out.println("=======================================================");
       ciktiAlimi.println("=======================================================");
       System.out.print("gitmek istenilen yer : ");
       ciktiAlimi.close();
       int selLoc = input.nextInt();
       while(selLoc <0 || selLoc > 7){
           System.out.print("Lütfen geçerli bir değer giriniz : ");
           selLoc = input.nextInt();
    }
       switch(selLoc){
           case 1 :
              location = new GuvenliEv(player);      
              break ;
           case 2 : 
               location = new KoyAlani(player);
               break ;
           case 3 :
               location = new Orman(player);
               break ;
           case 4 :
               location = new Kasaba(player);
               break; 
           case 5 : 
               location = new Kale(player);
               break ;
           case 6 :
               location = new Magaza(player);
               break ;
           case 7 :
               System.out.println("Oyundan çıkış yapmak istediğinize eminmisiniz (e/h)");
               String secim = input.next();
               secim = secim.toUpperCase();
               if(secim.equals("H")){
               OyunAkisi();
               }
               else{
               System.out.println( "Oyundan çıkış yapılıyor"  );
               System.exit(0);                   
               }
           default :
               location = new GuvenliEv(player);
       }
       if (location.getClass().getName().equals("Proje.GuvenliEv")) { // egerki lokasyon safeHoyuse gösterdiginde 4 itemin boolean degeri true donmus ise oyunu kazanmıs oluruz ve biter 
				if (player.getInv().isFirewood() && player.getInv().isFood() && player.getInv().isDrink() && player.getInv().isGoldRing()) {
					System.out.println("Tebrikler "+ player.getName() + " 4 önemli itemi toplayarak oyunu kazandın !!!");
					DosyaSil(); // oyun bittikten sonra SavasDegerleriTxt dosyası silinir
                                        break;
                                }   
			}
       if(!location.mapLoc()){  // mapLocation metodu false dönerse 
            System.out.println("Oyun Bitti");
            break ;
     }
   }
 }
   public void DosyaSil(){
        File f = new File("SavasDegerleri.txt");
        if(!f.exists()){
            System.out.println("Dosya bulunamadığından silinemedi");
        }
        else{
            f.delete();
            System.out.println(f.getName() + " adlı dosya silindi");
        }
    }
}