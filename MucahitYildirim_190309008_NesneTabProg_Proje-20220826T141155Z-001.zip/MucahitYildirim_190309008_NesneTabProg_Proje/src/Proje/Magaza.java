/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proje;

/**
 *
 * @author pc
 */
public class Magaza extends normalLoc{
        int itemNumber ;
    
    public Magaza(Player player) {
        super(player, "Mağaza");
        this.name = name ;
    }
    public boolean mapLoc(){
        int secim ;
        int secimNumber;
        System.out.println("======== MAĞAZA ========");
        System.out.println(" Mevcut Para : " + player.getPara());
        System.out.println("1. Silahlar");
        System.out.println("2. Zırhlar");
        System.out.println("3. Can Yükseltme");
        System.out.println("4. çıkış");
        System.out.print("seciniz : " );
        System.out.println("========================");
        secim = input.nextInt();
        switch(secim){
            case 1 : 
                secimNumber = silahMenu();
                silahAlim(itemNumber);
                break ; 
            case 2: 
                secimNumber = zirhMenu();
                zirhAlim(itemNumber);                
                break ;                
            case 3 : 
                secimNumber =canUpr();
                canArtir(itemNumber);
                break ;
                
        }
        return true ;
    }
    
    public int canUpr(){
        System.out.println("*************************************************");
        System.out.println("*1. az düzey \t  ||Para :15 Eklenen can : 10 ||*");
        System.out.println("*2. Orta düzey\t  ||Para :25 Eklenen can : 20 ||*");
        System.out.println("*3. yüksek düzey  ||Para :35 Eklenen can : 30 ||*");
        System.out.println("*4. Çıkış\t\t\t\t\t*");
        System.out.println("*************************************************");
        System.out.print(" Can yükseltme potu seçiniz : ");
        itemNumber =  input.nextInt() ;
        return itemNumber ;    
    }
    
        public void canArtir(int itemNumber){
        int ekCan = 0 , fiyat = 0 ;
        String cName = null ;
        if(itemNumber > 0 || itemNumber < 4){
            switch(itemNumber){
                case 1: 
                   ekCan = 10 ; 
                   cName =  "Az düzey can yükseltme potu" ;
                   fiyat = 15 ; 
                   break ;
                case 2 : 
                    ekCan = 20 ;
                    cName = " orta düzey can yükseltme potu" ; 
                    fiyat = 25 ;
                    break ; 
                case 3 : 
                    ekCan = 30 ;
                    cName = "yüksek düzey can yükseltme potu " ; 
                    fiyat = 35 ;
                    break ;
                case 4 : 
                    System.out.println("Çıkış yapılıyor");
                default :
                    System.out.println("Hatalı seçim yaptınız !! ");
                    break ; 
            }
              if(fiyat > 0){
                 if(player.getPara() > fiyat){  
           player.getInv().setSaglik(ekCan);
           player.setSaglik(player.getTotatlCan());
           player.getInv().setcName(cName);
           player.setPara(player.getPara() - fiyat);
              System.out.println(cName +" satın aldınız , eklenen can " + player.getInv().getSaglik());
              System.out.println("Toplam can : " + player.getSaglik());
              System.out.println("\nKalan para : " + player.getPara()); 
          }
          else {
              System.out.println("bakiye yetersiz");
          }
            }
        }
    }

    
    
    public int zirhMenu(){
        System.out.println("****************************************************");
        System.out.println("*1. Hafif\t||Para :15 EngellenenHasar  : 1 || *");
        System.out.println("*2. Orta\t||Para :35 Engellenen Hasar : 3 || *");
        System.out.println("*3. Ağır\t||Para :40 Engellenen Hasar : 5 || *");
        System.out.println("*4. Çıkış\t\t\t\t\t   *");
        System.out.println("****************************************************");
        System.out.print("Zırh seçiniz : ");
        itemNumber =  input.nextInt() ;
        return itemNumber ;   
    }
    
    public void zirhAlim(int itemNumber){
           int engellenenHasar = 0  , fiyat = 0 ;
        String aName = null ;
        if(itemNumber > 0 || itemNumber <4){
            switch(itemNumber){
                case 1 :
                    engellenenHasar = 2 ;
                    aName = "hafif zırh";
                    fiyat = 5;
                    break;
                case 2 : 
                    engellenenHasar = 3 ;
                    aName = "Orta zırh";
                    fiyat =25 ;
                    break ;
                case 3 : 
                    engellenenHasar = 5 ;
                    aName = "Ağır zırh"; 
                    fiyat = 40;
                    break ;
                case 4 : 
                    System.out.println("Çıkış yapılıyor.");
                default :
                    System.out.println("Geçersiz işlem");
                    break ;
            }
            if(fiyat > 0){
                 if(player.getPara() > fiyat){  
           player.getInv().setArmor(engellenenHasar);
           player.getInv().setaName(aName);
           player.setPara(player.getPara() - fiyat);
              System.out.println(aName +" satın aldınız , engellenen hasar " + player.getInv().getArmor());
              System.out.println("\nKalan para : " + player.getPara()); 
          }
          else {
              System.out.println("bakiye yetersiz");
          }
            }
        }
    }
   
    public int silahMenu(){
        System.out.println("******************************************");
        System.out.println("*1. Tabanca\t  ||Para :15 Hasar : 2 ||*");
        System.out.println("*2. Kılıç\t  ||Para :20 Hasar : 3 ||*");
        System.out.println("*3. Tüfek\t  ||Para :30 Hasar : 5 ||*");
        System.out.println("*4. Murver Asa \t  ||Para :35 Hasar : 7 ||*");
        System.out.println("*5. Otamatik Silah||Para :40 Hasar : 9 ||*");
        System.out.println("*6. Çıkış\t\t\t\t *");
        System.out.println("******************************************");
        System.out.print("Silah seçiniz : ");
        itemNumber =  input.nextInt() ;
        return itemNumber;     
    }
    
    
    
    
    public void silahAlim(int itemNumber){
        int damage = 0  , fiyat = 0 ;
        String wName = null ;
        if(itemNumber > 0 || itemNumber <6){
            switch(itemNumber){
                case 1 :
                    damage = 2 ;
                    wName = "Arbalet";
                    fiyat = 5;
                    break;
                case 2 : 
                    damage = 3 ;
                    wName = "Kılıç";
                    fiyat =35 ;
                    break ;
                case 3 : 
                    damage = 5 ;
                    wName = "Tüfek"; 
                    fiyat = 30 ;
                    break ;
                case 4 : 
                    damage = 8 ;
                    wName = "Mürver Asa";
                    fiyat = 35 ;
                    break ; 
                case 5 : 
                    damage = 9 ; 
                    wName = "Otomatik Silah";
                    fiyat = 40 ;
                    break ; 
                case 6 :
                    System.out.println("Çıkış yapılıyor.");
                default :
                    System.out.println("Geçersiz işlem");
                    break ;
            }
            if(fiyat > 0){
                 if(player.getPara() > fiyat){  
           player.getInv().setDamage(damage);
           player.getInv().setwName(wName);
           player.setPara(player.getPara() - fiyat);
              System.out.println(wName +" satın aldınız , önceki hasar : " + player.getHasar() + "Güncel hasar : " + player.getTotalDamage());
              System.out.println("\nKalan para : " + player.getPara()); 
          }
          else {
              System.out.println("bakiye yetersiz");
          }
            }
        }
    }
}
