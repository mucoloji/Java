
package Proje;

import java.util.Scanner;


public abstract class Lokasyon {
    protected Player player ;
    protected String name ;
    Scanner input = new Scanner(System.in);
    
    
    public abstract boolean mapLoc(); // abstract olarak tanımla 
    
    Lokasyon(Player player){
        this.player = player;
    }
    
    public void setPlayer(Player player) {
        this.player = player;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Player getPlayer() {
        return player;
    }

    public String getName() {
        return name;
    }

 
}
