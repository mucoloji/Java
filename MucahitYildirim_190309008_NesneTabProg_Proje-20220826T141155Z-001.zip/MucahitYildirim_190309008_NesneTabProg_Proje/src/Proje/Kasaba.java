/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proje;

/**
 *
 * @author pc
 */
public class Kasaba extends SavasAlani {
    
    public Kasaba(Player player) {
        super(player, "Kasaba", new Sovalye() , "İçecek");
    }
    

    
}
