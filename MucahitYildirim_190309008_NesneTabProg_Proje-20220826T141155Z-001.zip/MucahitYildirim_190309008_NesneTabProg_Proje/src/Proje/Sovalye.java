/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proje;

/**
 *
 * @author pc
 */
public class Sovalye extends Enemy{
    
    public Sovalye(){
        super("Şövalye" , 7 , 18 , 12 , 4);
    }
}
