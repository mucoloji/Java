/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Proje;

import java.util.*;
import java.io.*;
public class Player {
    Scanner input = new Scanner(System.in);
    private int  hasar , saglik , para , rtrnSaglik;
    private String name , Cname ;
    private  Envanter ınv ;

    public Player(String name) {
        this.name = name;
        this.ınv = new Envanter();
    }
    
    public int getTotalDamage(){
        return this.getHasar() + this.getInv().getDamage();
    }
    
    public int getTotatlCan(){
        return this.getSaglik() + this.getInv().getSaglik();
    }
    public void karakterSecim(){
       switch(CharMenu()){
           //samuray seçild
           case 1 : 
               //System.out.println("Samuray seçildi ");
               createPlayer("Savaşçı" , 8 , 28, 35);
               break ;
           case 2 : 
                createPlayer("Okçu" , 12 , 18, 40);
               break ;
           case 3 :
               createPlayer("Şövalye" , 7 , 30, 45);
               break ;
           case 4 : 
               createPlayer("Suikastçı" , 8 , 227 , 520) ;  // oyunun ve magazanın daha kolay denenmesi icin saglik ve parayı yuksek degerde yaptim
               break ; 
           case 5: 
               createPlayer("Büyücü" , 10 , 25 ,55);
               break ; 
               
           default :
               System.out.println("Yanlış seçim yaptınız. Tekrar deneyiniz : ");
       }
        System.out.println(getCname() + "\t Hasar : " + getHasar() + "\tSağlık : " + getSaglik() + "\tPara : " + getPara());
       
       
    }

   
    public void createPlayer(String name , int hasar , int saglik , int para){
         setCname(name);
               setHasar(hasar);
               setSaglik(saglik);
               setPara(para);
               setRtrnSaglik(saglik);
    }
    
    
    public int CharMenu(){String dosya = "Baslangic.txt"; 
        
        PrintWriter ciktiAlimi = null ;
        try
        {
            ciktiAlimi = new PrintWriter (new FileOutputStream(dosya));
        }
        catch (FileNotFoundException hata ){
            System.out.println("AnaEkran.txt dosyası olusturulurken hata oldu...");
            System.exit(0);
        }
        System.out.println("Lütfen karakter seçiniz  \n");
        System.out.println("**********************************************************************");
        System.out.println("*1- witcher(savaşçı)\tHasar : 8\tsağlık : 28\t Para : 35   *");       
        System.out.println("*2- Robin(okçu) \tHasar : 12\tsağlık :  18\t Para : 40   *");
        System.out.println("*3- Dark Knight(şövalye)Hasar : 7\tsağlık : 35\t Para : 45   *");
        System.out.println("*4- gamora(suikastçı)\tHasar : 8\tsağlık : 27\t Para : 50   *");
        System.out.println("*5- Gandalf(büyücü)\tHasar : 10\tsağlık : 25\t Para : 55   *");
        System.out.println("**********************************************************************");
        System.out.print("seciminiz : ");
        System.out.print("");
        int charID = input.nextInt();

        while(charID < 1 || charID >=6 ){
            System.out.print("Lütfen geçerli bir sayı giriniz :  ");
            charID = input.nextInt();
        }
        System.out.println("");
        System.out.println("================================================================================================================");
        System.out.println("Seçimin başarıyla gerçekleştirildi "+ this.name + ". Şimdi bütün itemleri toplayıp oyunu bitirmen gerekiyor. Bol şans..."); 
        System.out.println("");
        System.out.print("Seçtiğin karakter ve özellikleri  -->   " );     
        return charID ;
    }
    
    
    
    public Envanter getInv(){
        return ınv ;
    }

    public void  setInv(Envanter ınv){
        this.ınv = ınv ;
    }
      
    public void setHasar(int hasar) {
        this.hasar = hasar;
    }

    public void setSaglik(int saglik) {
        this.saglik = saglik;
    }

    public void setPara(int para) {
        this.para = para;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCname(String Cname) {
        this.Cname = Cname;
    }

    public int getHasar() {
        return hasar;
    }

    public int getSaglik() {
        return saglik;
    }

    public int getPara() {
        return para;
    }

    public String getName() {
        return name;
    }

    public String getCname() {
        return Cname;
    }

    public void setRtrnSaglik(int rtrnSaglik) {
        this.rtrnSaglik = rtrnSaglik;
    }

    public int getRtrnSaglik() {
        return rtrnSaglik;
    }
    
    
}

